@extends('errors/masterError')
@section('title', '')


@section('content')

    <h1>Všetko funguje, iba ste asi zablúdili.</h1>

@endsection