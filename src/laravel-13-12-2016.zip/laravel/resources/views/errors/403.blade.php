@extends('errors/masterError')
@section('title', '')


@section('content')

    <h1>Na prístup k tejto stránke sa najskôr musíte prihlásiť.</h1>

@endsection