@extends('errors/masterError')
@section('title', '')


@section('content')

	<h1>Server je dočasne v technickej prestávke.</h1>

@endsection