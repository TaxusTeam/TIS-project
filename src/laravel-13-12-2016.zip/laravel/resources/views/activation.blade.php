<html>
<body>
<h2>Thank you for registration!</h2>
<p>
	Your accout is waiting for trainer acivation.

	FSPH Team.
</p>
</body>
</html>


