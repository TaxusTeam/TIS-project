@extends('app')

@section('content')

    <h1>Zapisnik</h1>
    <p>Vizualizacia naplnanie cielov a vkladanie odbehnutej vzdialenosti.</p>



@endsection